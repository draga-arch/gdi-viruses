this is a trojan

im not responsible for any damage
im too lazy to write