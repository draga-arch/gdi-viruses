this is a gdi virus

do not run on your main pc.
im too lazy to write