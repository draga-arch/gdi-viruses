this gdi trojan was made by mrflamflam

when you launch this file you agree ur the only one causing harm to your device.