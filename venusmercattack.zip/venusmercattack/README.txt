This is a trojan, not a joke

Credits to Provr70 for helping me.
This trojan was made by provr70 and main creator was mrflamflam! Not the real mrflimflam. Idiots.


We will not be responsible for any damages made to your computer.
Run at your own risk.
If any damage occurs contact provr70isme or baba099038 on discord.




:)





-VENUSMERCATTACK.EXE